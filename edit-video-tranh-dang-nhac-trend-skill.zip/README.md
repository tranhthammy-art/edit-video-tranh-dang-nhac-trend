# edit-video-tranh-dang-nhac-trend

Skill dựng quảng cáo tranh theo video gốc và nhạc người dùng cung cấp.

## Cài đặt

1. Tải `edit-video-tranh-dang-nhac-trend-skill.zip` từ repo này và giải nén vào `customs/skills/edit-video-tranh-dang-nhac-trend/` trong VAS. Các tệp `SKILL.md`, `scripts/`, `assets/`, `workflow.md` và `plan-schema.md` phải nằm cùng thư mục skill.
2. Đọc `SKILL.md`, `workflow.md`, `plan-schema.md` và `AGENTS.md` của bản VAS đang dùng.
3. Chạy `python scripts/vas.py doctor` tại thư mục gốc VAS. Khi cần dựng, cài Python 3.11+, Pillow, NumPy, FFmpeg và ffprobe theo quy tắc phụ thuộc của VAS.
4. Để gọi từ ChatGPT trình duyệt, cấu hình plugin/MCP VAS riêng cho tài khoản hoặc workspace đó và máy VAS. Kiểm tra công cụ `checkVAS` trước khi gửi nguồn. Máy VAS phải bật trong lúc dựng.

Repo này không chứa khóa API, cấu hình tunnel, footage hoặc dữ liệu fanpage. Việc cài skill vào VAS và việc kết nối ChatGPT web là hai bước riêng. Phiên bản skill công khai chỉ dựng và giao video để duyệt; không tự đăng Facebook.

Sau khi cài, chờ người dùng cung cấp video gốc và nhạc. Không tự phiên âm hay dựng thử.
