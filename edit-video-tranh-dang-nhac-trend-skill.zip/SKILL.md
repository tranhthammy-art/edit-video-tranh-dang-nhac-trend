---
name: edit-video-tranh-dang-nhac-trend
description: Dựng video quảng cáo tranh 10 giây theo video và nhạc do người dùng cung cấp, kiểm tra bản dựng rồi gửi để duyệt.
---

# Edit video tranh dạng nhạc trend

Đọc `workflow.md` và `plan-schema.md` trước khi lập kế hoạch. Script dựng nằm trong `scripts/`; font và SFX có giấy phép trong `assets/`. Làm việc trong job VAS, giữ footage gốc, tạo phiên bản mới khi sửa.

- Nhận video gốc và nhạc; không tự thay bài nhạc. Kiểm tra metadata và xem khung hình thật trước khi lập plan.
- Video mặc định 10 giây, 720×1280, 30 fps. Footage phủ đầy 9:16; crop có chủ ý, không bóp méo hoặc che đầu/mặt/tóc bằng chữ. Line-height tối thiểu 1,25.
- Không bịa giá, chất liệu, kích thước, ưu đãi hay nhận nhạc đang trend khi chưa có căn cứ.
- Phân tích nhạc bằng `scripts/analyze_music.py`; dựng bằng `scripts/render.py` theo `plan-schema.md`. Python 3.11+, Pillow, NumPy, FFmpeg và ffprobe là phụ thuộc cần kiểm tra.
- Giải mã và kiểm tra video/audio cuối; xem các frame đầu, giữa, cuối và quanh chuyển cảnh. Gửi video cùng caption để người dùng duyệt. Không đăng lên mạng xã hội nếu chưa có lời duyệt riêng.
- Video chỉ có nhạc và chữ không cần phiên âm. Nếu người dùng giao footage có lời nói và yêu cầu phiên âm, có thể dùng Faster Whisper cục bộ của VAS; không tự phiên âm sau khi cài.

Trong ChatGPT web, cần cầu nối MCP đến máy VAS đang chạy. Một repo GitHub không tự cấp quyền truy cập tệp cục bộ hoặc đăng ký MCP cho mọi tài khoản ChatGPT. Chỉ nhận là đã kết nối khi `checkVAS` thành công.
