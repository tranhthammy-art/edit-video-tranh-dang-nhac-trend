# Quy trình dựng video tranh theo nhạc

## Nhận nguồn và phân tích

Nguồn tối thiểu là video gốc và một file/link nhạc nền. Thông tin bán hàng thêm vào khi đã biết; không lục lại sản phẩm cũ để điền mặc định. Giữ file gốc, đăng ký input trong job và lưu URL nguồn nhạc. Với nhạc lấy từ clip, tách track nhạc; không chồng track nguồn lên nhạc mới. Nếu clip nhạc có lời nói quảng cáo của người khác, chọn đoạn không có lời hoặc báo vấn đề, không tự nhận đã tách sạch.

Đo duration, resolution, FPS/PTS, rotation, audio. Xem cảnh trưng bày, góc cầm, phản chiếu/bóc màng, chi tiết và khoảnh khắc tranh dựng thẳng; xem dày hơn quanh điểm đổi ý. Phân biệt cái nhìn thấy, cái đo được và đề xuất biên tập. Không gọi contact sheet vài frame là kiểm tra mọi frame.

Giữ khung 9:16 phủ đầy. Helper mặc định xuất 720×1280 như bản mẫu; nếu người dùng yêu cầu giữ nguồn 1080 hoặc độ phân giải khác, thích ứng renderer trong job theo plan-schema.md. Không upscale 720 lên 1080 để giả thêm chi tiết. Xác định vùng đầu/mặt/tóc theo shot và cả trong chuyển động; đặt chữ vào vùng trống không che hình. Nếu vùng trống thay đổi, dịch cue theo shot hoặc rút copy. Không tạo dải nền lớn hay thu nhỏ footage chỉ để đặt chữ.

## Bài Facebook và ý chữ

Nếu `bv-anh` có sẵn, đọc nó rồi chọn một bài nền để chắt ý cho video và viết ba bài đăng khác phong cách theo publishing.md. Mỗi bài có: câu mở gợi nhu cầu thật, chi tiết đặc trưng trong tranh, tên sản phẩm, dữ kiện bán hàng đã biết, lời mời nhắn tin và đúng 10 hashtag liên quan. Không bịa ship, chống nước, chống xước, độ bền, số lượng, ưu đãi hoặc khổ tranh. Không mặc định mọi tranh dành cho salon.

Chấm điểm biên tập trên độ tự nhiên, bám hình, rõ sản phẩm và phù hợp người mua; tự chọn bài nền tốt nhất, không bắt người dùng chọn giữa nhiều phương án. Ba bản đăng phải khác cách mở, cấu trúc và CTA, không chỉ thay vài từ. Nếu thiếu `bv-anh`, vẫn hoàn thành bài theo các tiêu chí trên và nói đúng việc đã làm.

Rút khoảng bốn ý cho 10 giây, mỗi cue thường hai dòng:

| Nhịp | Mục tiêu | Copy phù hợp |
|---|---|---|
| 0–1,6 giây | Dừng lướt | Lợi ích trang trí + giá nếu đã biết; nếu chưa biết giá, nhấn chi tiết có thật |
| 1,6–4,8 giây | Hiểu món đang bán | Tên loại tranh + không gian dùng phù hợp |
| 4,8–7,4 giây | Có lý do quan tâm | Chất liệu/kích thước có dữ kiện, hoặc nét hình ảnh nổi bật |
| 7,4–10 giây | Biết bước tiếp theo | Một điểm mạnh đã nêu + “Nhắn tin chọn mẫu” |

Đây là nhịp tham khảo, không phải nội dung cố định. Khi không biết giá/chất liệu, thay bằng mô tả hình ảnh; không dùng placeholder trên video. Không đưa cả caption hoặc hashtag vào video. Không tuyên bố video chắc chắn viral.

## Nhạc, nhịp cắt và chuyển cảnh

Phân tích đoạn nhạc dài hơn thời lượng đích. Chọn cửa sổ 10 giây có năng lượng/onset rõ, tránh khoảng im dài, đoạn mở đang yếu hoặc cuối cắt ngang một cao trào. `analyze_music.py` hỗ trợ xếp hạng cửa sổ, không nhận diện giấy phép hoặc chứng minh độ phổ biến. Nghe nếu có công cụ; nếu không, chọn theo dữ liệu và nêu giới hạn.

Điểm xuất phát khoảng chín shot: ba nhịp ngắn mở đầu, hai shot giới thiệu, hai cảnh trám chi tiết, một hero shot và một giữ hình kết. Cắt tại động tác/nhịp khi phù hợp; tránh lặp cảnh quá mức. Footage ngắn có thể tái sử dụng góc khác, freeze sạch, punch-in vừa phải hoặc speed ramp; vẫn giữ tranh đầy khung và tránh crop mất nội dung. Không bắt buộc đủ mọi kỹ thuật trong mọi video.

Chuyển cảnh ưu tiên jump cut có chủ ý, zoom nhấn hoặc whip/light sweep mềm tại đổi ý. Trong 10 giây chỉ cần vài chuyển cảnh rõ; không chớp trắng mỗi cut. Freeze nên chọn tranh dựng thẳng, thấy sản phẩm đẹp, không phải khung người đang cúi hoặc tấm tranh nghiêng khỏi hình.

## Chữ động

Helper dùng Be Vietnam Pro Black như bản mẫu; có thể dùng thêm font SemiBold đóng gói cho dòng hỗ trợ khi thích ứng renderer trong job. Trắng ngà, viền mint mảnh, glow vừa phải, vàng ấm cho giá/thông số. Không hộp đen; stroke chỉ để đọc được trên nền thực, không làm halo dày che nét chữ.

Baseline của toàn dòng phải thống nhất cho dấu Việt. Vị trí mỗi ký tự theo `font.getlength(prefix)` có kerning, vẽ với `anchor='ls'` và cùng baseline; không căn từng glyph riêng theo đỉnh bbox. Chừa vùng cho dấu, stroke, glow và overshoot. Line-height ≥1,25, mặc định 1,28.

Kicker vào trước, từ khóa lớn chạm nhịp sau, hỗ trợ xuất hiện cuối; không reveal mọi phần mới cùng lúc. Dùng tối đa vài họ nhất quán: ghép ký tự hoặc từ, pop có overshoot khoảng 10–20%, quét sáng/underline. Cụm mới có SFX phù hợp; chữ giữ ổn định đủ để đọc sau khi chạm. Không giữ chữ nhảy/rung suốt shot. Xem cả frame giữa animation để tránh một chữ xoay/trượt vào mặt rồi mới đứng đúng vị trí.

## Mix và nguồn tài nguyên

Dùng nhạc người dùng đã chọn, không tự đổi sang piano vì bản skill gốc từng có piano. Căn đoạn đầu gần nhịp nhấn, fade âm đầu vài chục mili giây và đuôi 0,2–0,4 giây khi phù hợp. Nếu nhạc ngắn hơn đích, chọn lặp có crossfade theo nhịp hoặc rút thời lượng với giải thích; không nối vòng cứng gây tiếng nhảy.

SFX CC0 đóng gói có thể dùng: sweep/open đầu cụm; pluck/drop tại giá hoặc thông số; confirmation ở CTA. Thường 4–7 sự kiện trong 10 giây là đủ. Cắt im lặng đầu, căn transient với thời điểm chữ chạm, fade ngắn tránh click. Không bíp từng ký tự. Mix SFX nhỏ hơn nhạc; nếu có lời được yêu cầu giữ, duck nhạc theo lời thay vì áp preset nhạc-only.

Chuẩn hóa hai lượt về khoảng −14 LUFS và peak tối đa −1 dBTP, encode AAC rồi đo lại. Không kết luận “nghe hay” khi chỉ có số đo. Lưu font/SFX credits và URL nhạc; không khẳng định nhạc công khai đồng nghĩa được dùng thương mại.

## Plan, render và QA

Đọc `plan-schema.md` trước khi tạo plan. Plan dùng source/nhạc local hiện tại, shot trim/speed, cue text/animation/vị trí, nhạc trim và SFX; lưu trong job. Các helper nhận đầu vào qua tham số, không phụ thuộc đường dẫn hay nội dung của video mẫu cũ. Chỉ cài dependency đang thiếu, dùng shared `.venv` và FFmpeg hiện có.

Kiểm tra bản dựng:

- Giải mã toàn bộ video/audio không lỗi; probe video và audio đủ thời lượng, đúng 9:16/FPS; 10 giây ở 30 FPS phải đủ 300 frame.
- Xem đầu, giữa, cuối; từng cut và frame vào/giữ/ra của mỗi cue. Kiểm tra chữ Việt, baseline, mép khung, overshoot, mặt/tóc, vùng UI, shot sáng/tối, transition và CTA cuối. Không tự nhận đã xem mọi frame nếu chỉ lấy mẫu.
- Đo mix sau AAC; kiểm tra tiếng nổ/clipping, độ lệch mức giữa đoạn nhạc và SFX. Nghe nếu được; nêu giới hạn nếu chỉ đo.
- Nếu có vấn đề, sửa rồi kiểm tra lại phần bị ảnh hưởng. Giữ phiên bản trước và tối đa ba vòng QA cho một hướng dựng; nếu còn vấn đề thật, bàn giao với giới hạn rõ thay vì che giấu.

Bàn giao video hoàn chỉnh bằng đường dẫn tuyệt đối có thể tải, kèm ba bài Facebook và fanpage tương ứng. Cập nhật metadata/job và nguồn. **Hỏi duyệt video và chờ trước khi đăng.** Sau khi được duyệt trong ngữ cảnh đăng lên ba page, dùng quy trình publishing.md; không đăng TikTok hoặc nơi khác ngoài yêu cầu. Nếu người dùng yêu cầu sửa, chưa đăng bản cũ và xin duyệt lại bản sửa.
