# Kế hoạch dựng và helper

Đọc trước khi tạo plan. Helper nhận **tệp local**; tải URL bằng skill downloader phù hợp trước. Các path trong JSON tính từ thư mục của plan; nên dùng path tuyệt đối. Không lấy timestamps của ví dụ gắn vào footage mới.

```powershell
.venv/Scripts/python.exe customs/skills/edit-video-tranh-dang-nhac-trend/scripts/analyze_music.py --input <nhạc-local> --duration 10 --output <job/edit/music_analysis.json>
.venv/Scripts/python.exe customs/skills/edit-video-tranh-dang-nhac-trend/scripts/render.py --plan <job/edit/plan.json> --output <job/output/final_video.mp4> --work-dir <job/edit/render>
```

Helper tìm FFmpeg/ffprobe trên PATH, sau đó config VAS hiện có; có thể chỉ định `--ffmpeg <exe>` và `--ffprobe <exe>`. Dependency Python trong `scripts/requirements.txt`: Pillow và NumPy. Cài vào `.venv` chung khi thiếu, không cài lại vô cớ. Không cần Node/Remotion.

## Trường plan

- `source`: video gốc; `duration`: mặc định 10; `fps`: 30. Renderer hiện xuất 720×1280, đầy khung 9:16, phù hợp mẫu đã chốt. Nếu người dùng yêu cầu độ phân giải/FPS khác, thích ứng renderer trong **job**, không âm thầm đổi yêu cầu hoặc sửa bản gốc skill.
- `shots`: mảng `{start, duration, mode, speed?, source?}`. `start` là thời gian nguồn, `duration` là thời gian đầu ra. `mode`: `normal`, `intro` (zoom 1,07→1), `freeze`, `ramp`. `speed` áp dụng cho normal. Tổng duration các shot phải bằng duration video. Kiểm tra cả phần footage cần tiêu thụ của ramp bằng preview; helper chỉ kiểm tra sơ bộ theo duration/speed.
- `music`: `{path, start, gain?}`. Cắt đúng đoạn nhạc đủ độ dài. Nhạc thiếu độ dài sẽ báo lỗi; nếu thực sự cần lặp, chuẩn bị WAV có crossfade rồi đưa vào, không nối lặp cứng.
- `cues`: mảng `{start, end, y?, elements, accent?, accent_style?, shine_at?}` trên timeline đầu ra. `y` là tọa độ của band chữ cao 215 px trên khung 720×1280; mặc định 0. Có thể đổi theo từng cảnh để tránh mặt, nhưng phải xem frame thật và tránh UI. Không cue chồng nhau; dùng nhiều elements trong cùng cue.
- `elements`: `{text, size, baseline, animation, delay?, color?, cx?, stagger?}`. Mọi tọa độ theo canvas 720 px. `animation`: `words` (theo từ), `chars` (ghép ký tự), `pop` (nảy), `drop` (rơi). `color`: `white`, `mint`, `gold`, hoặc mã màu. `cx` chỉ cho pop/drop, mặc định 360. `stagger` chỉ cho chars; mặc định 0,012 giây. `delay` tương đối với đầu cue. `baseline`: 30–205. Cỡ 16–120; helper giảm cỡ dòng quá rộng nhưng không tự giải quyết mọi va chạm giữa các elements.
- `accent_style`: `{delay, y, left, right}` tương đối band; mặc định 0,42/202/200/520. `shine_at`: thời điểm bắt đầu quét sáng, mặc định 0,85 giây.
- `sfx`: mảng `{time, asset, peak?}`; `asset` là tên OGG trong assets/audio, không phải URL. Peak tham khảo 0,055–0,085. Gắn âm theo cụm/điểm chạm; không bíp mỗi ký tự.

## Ví dụ cấu trúc một cue

```json
{
  "start": 1.6,
  "end": 4.8,
  "y": 0,
  "elements": [
    {"text":"TRANH TRANG TRÍ", "size":43, "baseline":87, "animation":"chars", "delay":0.02, "color":"white", "stagger":0.012},
    {"text":"ĐIỂM NHẤN CHO GÓC TƯỜNG", "size":28, "baseline":158, "animation":"words", "delay":0.38, "color":"white"}
  ],
  "accent_style":{"delay":0.42,"y":109,"left":111,"right":609},
  "shine_at":1.02
}
```

Đây là ví dụ kỹ thuật, không phải copy bắt buộc. Ghi đúng tên sản phẩm và chất liệu đã biết. Nếu người dùng chỉ đưa video/nhạc, chọn câu trung tính bám hình thay vì tự thêm giá hay vật liệu.

## Bố cục đã dùng cho mẫu salon

Chỉ dùng giá/chất liệu này khi người dùng xác nhận sản phẩm đó. Bốn cue 0–1,6 / 1,6–4,8 / 4,8–7,4 / 7,4–10 giây. Các dòng có cùng baseline; không căn từng glyph bằng bounding box đỉnh riêng.

- Hook: kicker 28/baseline62; giá 88/cx360/baseline174; nhãn “CHỈ TỪ” 24/cx125/baseline156 và đơn vị 30/cx560/baseline156.
- Sản phẩm: tên 43/baseline87; nơi dùng 28/baseline158.
- Vật liệu: tiêu đề 40/baseline80; nhãn 32/cx240/baseline169, thông số 76/cx450/baseline177.
- CTA: giá 76/cx360/baseline90, nhãn 24/cx125/baseline80, đơn vị30/cx560/baseline80; lời mời32/baseline188.

Đặt khoảng dòng ít nhất 1,25; các phần của cùng một hàng giá có thể khác cỡ và chung ý. Thu cỡ hoặc thay câu ngắn hơn khi cần, không ép ba hàng vào vùng quá hẹp. Band alpha bị cắt ở y24–211; phải xem cả pha nảy để tránh mất dấu/glow ở biên. Nếu mặt đi vào band, đổi vị trí cue hoặc cảnh, không thu nhỏ footage để nhường chỗ.

## Đầu ra và giới hạn kiểm tra tự động

Trong work-dir: clips, base, type.mov, mix.wav, `render_report.json`, `verify/contact_sheet.jpg`, `verify/loudness.txt`. Helper concat lossless các đoạn, overlay cuối, master hai lượt, giải mã toàn bộ đầu ra và probe metadata. Contact sheet lấy mẫu quanh mỗi cut/cue và đầu/cuối, không phải kiểm tra bằng mắt mọi frame.

Agent **phải xem contact sheet/preview**, rà dấu, tràn, đầu/mặt, crop và CTA; xem dày hơn khi cần. Helper không phát hiện mặt tự động, không tự nghe nhạc, không xác minh thông tin thương mại hoặc bản quyền. Đọc loudness sau AAC: mục tiêu khoảng -14 LUFS, true peak ≤ -1 dBTP. Giữ report và ghi rõ giới hạn nếu chưa nghe trực tiếp.
