"""Suggest an energetic excerpt and onset times; this is a measured suggestion, not listening."""
import argparse,json
from pathlib import Path
import numpy as np
from common import binary,decode,outside_skill

def analyze(samples,duration):
 mono=samples.mean(axis=1);hop=480;count=len(mono)//hop
 if not count:raise ValueError('Nhạc rỗng hoặc quá ngắn.')
 rms=np.sqrt((mono[:count*hop].reshape(count,hop)**2).mean(axis=1));onset=np.maximum(0,np.diff(rms,prepend=rms[0]))
 window=max(1,round(duration*100));available=len(samples)/48000
 if available+1e-3<duration:raise ValueError('Nhạc ngắn hơn video; chọn nhạc khác hoặc lên kế hoạch loop/crossfade rõ ràng.')
 scores=np.convolve(onset,np.ones(window),mode='valid')+.15*np.convolve(rms,np.ones(window),mode='valid')
 best=int(np.argmax(scores));peaks=[]
 for i in np.argsort(onset)[::-1]:
  if onset[i]<=0:break
  if all(abs(int(i)-j)>=18 for j in peaks):peaks.append(int(i))
  if len(peaks)>=80:break
 preceding=[i for i in peaks if best-50<=i<=best+10 and i/100+duration<=available]
 start=min(preceding,key=lambda i:abs(i-best)) if preceding else best
 return {'suggested_start':round(start/100,3),'duration':duration,'source_duration':round(available,3),'onsets':sorted(round(i/100,3) for i in peaks),'method':'RMS và năng lượng onset; chưa nghe trực tiếp.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--duration',type=float,default=10);p.add_argument('--output',required=True);p.add_argument('--ffmpeg');a=p.parse_args()
 if a.duration<=0:raise ValueError('duration phải dương.')
 output=Path(a.output).resolve();outside_skill(output);output.parent.mkdir(parents=True,exist_ok=True)
 result=analyze(decode(binary('ffmpeg',a.ffmpeg),Path(a.input)),a.duration);output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=True))
if __name__=='__main__':main()
