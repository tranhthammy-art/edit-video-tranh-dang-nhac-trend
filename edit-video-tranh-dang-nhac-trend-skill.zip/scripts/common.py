from pathlib import Path
import json,os,shutil,subprocess

SKILL=Path(__file__).resolve().parents[1]
def binary(name,explicit=None):
 if explicit:return str(Path(explicit).resolve())
 found=shutil.which(name)
 if found:return found
 for root in SKILL.parents:
  config=root/'customs/tools/video-use/config.json'
  if config.exists():
   p=Path(json.loads(config.read_text(encoding='utf-8-sig'))['ffmpeg_dir'])/(name+('.exe' if os.name=='nt' else ''))
   if p.exists():return str(p)
 raise RuntimeError(f'Không tìm thấy {name}; cài FFmpeg hoặc truyền --{name}.')
def run(executable,args):
 p=subprocess.run([executable,'-y','-hide_banner','-loglevel','error',*map(str,args)],capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr.decode('utf-8',errors='replace'))
 return p
def probe(executable,path):
 p=subprocess.run([executable,'-v','error','-show_format','-show_streams','-of','json',str(path)],capture_output=True,check=True)
 return json.loads(p.stdout)
def decode(ffmpeg,path):
 import numpy as np
 p=run(ffmpeg,['-i',path,'-vn','-ac','2','-ar','48000','-f','f32le','-'])
 return np.frombuffer(p.stdout,dtype='<f4').reshape(-1,2).copy()
def path_from(value,base):
 p=Path(value).expanduser();return p.resolve() if p.is_absolute() else (base/p).resolve()
def outside_skill(path):
 if Path(path).resolve().is_relative_to(SKILL):raise ValueError('Đầu ra phải nằm trong workspace job, không ghi vào skill.')
