from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageChops
from functools import lru_cache
import math
from pathlib import Path
W,H=720,215
MINT='#83FFE1';WHITE='#FFFEF2';GOLD='#FFE16B';DARK='#073A3F'
FONT=str(Path(__file__).resolve().parents[1]/'assets/fonts/BeVietnamPro-Black.ttf')
@lru_cache(100)
def font(size):return ImageFont.truetype(FONT,size)
def ease(t):return 1-(1-max(0,min(1,t)))**3
def back(t):
 t=max(0,min(1,t));return 1+2.70158*(t-1)**3+1.70158*(t-1)**2
def width(s,size):return font(size).getlength(s)
def _tile(text,size,color,stroke=2):
 f=font(size);asc,desc=f.getmetrics();w=math.ceil(f.getlength(text))+32;im=Image.new('RGBA',(w,asc+desc+32));d=ImageDraw.Draw(im)
 # One font baseline for every word and character, including Vietnamese accents.
 d.text((16,16+asc),text,font=f,anchor='ls',fill=color,stroke_width=stroke+2,stroke_fill=DARK)
 d.text((16,16+asc),text,font=f,anchor='ls',fill=color,stroke_width=stroke,stroke_fill=MINT)
 alpha=im.getchannel('A');glow=Image.new('RGBA',im.size,MINT);glow.putalpha(alpha.filter(ImageFilter.GaussianBlur(4)).point(lambda a:int(a*.28)))
 glow.alpha_composite(im);return glow,asc
def put(out,text,size,cx,baseline,t,delay=0,color=WHITE,mode='pop'):
 if t<delay:return
 u=min(1,(t-delay)/.3);e=ease(u);im,asc=_tile(text,size,color)
 s=max(.02,back(u)) if mode=='pop' else 1
 if mode=='pop':im=im.resize((max(1,round(im.width*s)),max(1,round(im.height*s))),Image.Resampling.LANCZOS)
 im.putalpha(im.getchannel('A').point(lambda a:int(a*min(1,u*4))))
 y=baseline-(16+asc)*s
 if mode=='drop':y-=27*(1-e)
 out.alpha_composite(im,(round(cx-im.width/2),round(y)))
def line(out,text,size,baseline,t,delay=0,color=WHITE,stagger=.045):
 f=font(size);total=f.getlength(text);left=(W-total)/2
 for i,ch in enumerate(text):
  if ch==' ':continue
  u=(t-delay-i*stagger)/.24
  if u<=0:continue
  e=ease(u);im,asc=_tile(ch,size,color)
  x=left+f.getlength(text[:i])-16+(18 if i%2 else -18)*(1-e)
  y=baseline-16-asc-26*(1-e)
  im.putalpha(im.getchannel('A').point(lambda a:int(a*min(1,u*3))))
  out.alpha_composite(im,(round(x),round(y)))
def wordline(out,text,size,baseline,t,delay=0,color=WHITE):
 f=font(size);left=(W-f.getlength(text))/2;pos=0
 for i,w in enumerate(text.split(' ')):
  ww=f.getlength(w);put(out,w,size,left+f.getlength(text[:pos])+ww/2,baseline,t,delay+i*.09,color,'drop');pos+=len(w)+1
def shine(out,t,start=.8):
 u=(t-start)/.45
 if not 0<u<1:return
 band=Image.new('RGBA',(W,H));d=ImageDraw.Draw(band);x=-100+950*ease(u)
 d.polygon([(x-30,0),(x+5,0),(x+55,H),(x+20,H)],fill=(255,255,255,200));band.putalpha(ImageChops.multiply(band.getchannel('A'),out.getchannel('A')));out.alpha_composite(band)
def accent(out,t,delay=.4,y=202,left=200,right=520):
 u=(t-delay)/.32
 if u<=0:return
 end=left+(right-left)*ease(u);d=ImageDraw.Draw(out);d.line((left,y,end,y),fill=MINT,width=3)
 if u<1:d.ellipse((end-4,y-4,end+4,y+4),fill=GOLD)
def clean(out):
 out.paste((0,0,0,0),(0,0,W,24));out.paste((0,0,0,0),(0,211,W,H));return out
