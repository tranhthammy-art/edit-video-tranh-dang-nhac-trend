"""Render a reviewed, asset-grounded plan. Never invent copy or shot boundaries here."""
import argparse,json,math,subprocess,wave
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from common import SKILL,binary,run,probe,decode,path_from,outside_skill
import typography as ty

COLORS={'white':ty.WHITE,'mint':ty.MINT,'gold':ty.GOLD}
def cue_frame(cue,t):
 out=Image.new('RGBA',(720,215))
 for e in cue['elements']:
  size=int(e['size']);animation=e.get('animation','words');text=e['text'];color=COLORS.get(e.get('color','white'),e.get('color','white'))
  while size>16 and ty.width(text,size)+32>680:size-=1
  args=(out,text,size,float(e['baseline']),t,float(e.get('delay',0)),color)
  if animation=='chars':ty.line(*args,stagger=float(e.get('stagger',.012)))
  elif animation=='words':ty.wordline(*args)
  elif animation in ('pop','drop'):ty.put(out,text,size,float(e.get('cx',360)),float(e['baseline']),t,float(e.get('delay',0)),color,animation)
  else:raise ValueError(f'animation không hỗ trợ: {animation}')
 if cue.get('accent',True):
  a=cue.get('accent_style',{});ty.accent(out,t,float(a.get('delay',.42)),int(a.get('y',202)),int(a.get('left',200)),int(a.get('right',520)))
 ty.shine(out,t,float(cue.get('shine_at',.85)))
 return ty.clean(out)

def validate(plan,base,fp):
 if int(plan.get('fps',30))!=30:raise ValueError('Helper này dùng 30 fps; đổi renderer khi cần FPS khác.')
 if float(plan['duration'])<=0:raise ValueError('Thời lượng phải dương.')
 if not plan.get('shots') or not plan.get('cues'):raise ValueError('Cần shots và cues đã biên tập.')
 total=sum(float(s['duration']) for s in plan['shots'])
 if abs(total-float(plan['duration']))>1/30:raise ValueError('Tổng shot không khớp duration.')
 cache={}
 for s in plan['shots']:
  source=path_from(s.get('source',plan['source']),base)
  if source not in cache:cache[source]=probe(fp,source)
  duration=float(cache[source]['format']['duration']);start=float(s['start']);length=float(s['duration'])
  if start<0 or start>=duration or length<=0:raise ValueError('Khoảng shot không hợp lệ.')
  if s.get('mode','normal') not in ('normal','freeze','intro','ramp'):raise ValueError('Shot mode không hỗ trợ.')
  if s.get('mode','normal')!='freeze' and start+length*float(s.get('speed',1))>duration+.1:raise ValueError(f'Shot vượt footage: {source.name}')
 for c in plan['cues']:
  if not 0<=float(c['start'])<float(c['end'])<=float(plan['duration']):raise ValueError('Cue nằm ngoài video.')
  if not 0<=int(c.get('y',0))<=1065:raise ValueError('Vùng chữ nằm ngoài khung.')
  if not c.get('elements'):raise ValueError('Cue thiếu chữ.')
  for e in c['elements']:
   if not e.get('text') or not 16<=int(e['size'])<=120:raise ValueError('Text/cỡ chữ không hợp lệ.')
   if not 30<=float(e['baseline'])<=205:raise ValueError('Baseline phải nằm trong band chữ.')
 ordered=sorted(plan['cues'],key=lambda c:c['start'])
 if any(a['end']>b['start']+1e-6 for a,b in zip(ordered,ordered[1:])):raise ValueError('Cue chồng nhau; dùng elements trong cùng cue.')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',required=True);p.add_argument('--output',required=True);p.add_argument('--work-dir');p.add_argument('--ffmpeg');p.add_argument('--ffprobe');a=p.parse_args()
 planpath=Path(a.plan).resolve();plan=json.loads(planpath.read_text(encoding='utf-8-sig'));base=planpath.parent
 output=Path(a.output).resolve();work=Path(a.work_dir).resolve() if a.work_dir else output.parent/('_render_'+output.stem)
 outside_skill(output);outside_skill(work);ff=binary('ffmpeg',a.ffmpeg);fp=binary('ffprobe',a.ffprobe);validate(plan,base,fp)
 inputs={path_from(plan['source'],base),path_from(plan['music']['path'],base),planpath}
 inputs.update(path_from(s.get('source',plan['source']),base) for s in plan['shots'])
 if output in inputs:raise ValueError('Không ghi đè nguồn hoặc plan.')
 if any(i.is_relative_to(work) for i in inputs):raise ValueError('Nguồn và plan phải nằm ngoài work-dir để tránh bị ghi đè bởi tệp trung gian.')
 output.parent.mkdir(parents=True,exist_ok=True);work.mkdir(parents=True,exist_ok=True);(work/'clips').mkdir(exist_ok=True);(work/'verify').mkdir(exist_ok=True)
 duration=float(plan['duration']);paths=[];cuts=[];offset=0
 for i,s in enumerate(plan['shots']):
  source=path_from(s.get('source',plan['source']),base);mode=s.get('mode','normal');length=float(s['duration']);speed=float(s.get('speed',1))
  # Full-bleed 9:16: crop-to-fill, never shrink into decorative borders.
  vf='scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1'
  if mode=='intro':vf+=",zoompan=z='1.07-0.07*min(on/8,1)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=720x1280:fps=30"
  elif mode=='freeze':vf='select=eq(n\\,0),'+vf+f',tpad=stop_mode=clone:stop_duration={length+1}'
  elif mode=='ramp':vf="setpts='if(lt(T,0.4),PTS/1.5,(PTS-0.4/TB)/0.85+0.266667/TB)',"+vf
  elif speed!=1:vf=f'setpts=PTS/{speed},'+vf
  vf+=',eq=contrast=1.035:saturation=1.045,fps=30'
  clip=work/f'clips/{i:03}.mp4';run(ff,['-ss',s['start'],'-i',source,'-vf',vf,'-t',length,'-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',clip]);paths.append(clip);offset+=length;cuts.append(offset)
 concat=work/'concat.txt';concat.write_text(''.join("file '"+str(x).replace('\\','/').replace("'","'\\''")+"'\n" for x in paths),encoding='utf-8')
 run(ff,['-f','concat','-safe','0','-i',concat,'-c','copy',work/'base.mp4'])
 proc=subprocess.Popen([ff,'-y','-v','error','-f','rawvideo','-pixel_format','rgba','-video_size','720x1280','-framerate','30','-i','-','-c:v','qtrle',str(work/'type.mov')],stdin=subprocess.PIPE)
 try:
  for n in range(round(duration*30)):
   t=n/30;frame=Image.new('RGBA',(720,1280));cue=next((c for c in plan['cues'] if c['start']<=t<c['end']),None)
   if cue:
    band=cue_frame(cue,t-float(cue['start']));frame.alpha_composite(band,(0,int(cue.get('y',0))))
   proc.stdin.write(frame.tobytes())
 finally:proc.stdin.close()
 if proc.wait():raise RuntimeError('Mã hóa chữ thất bại.')
 music=decode(ff,path_from(plan['music']['path'],base));start=round(float(plan['music'].get('start',0))*48000);count=round(duration*48000);music=music[start:start+count]
 if len(music)<count:raise ValueError('Đoạn nhạc ngắn hơn video; chuẩn bị loop có crossfade trước.')
 mix=music*float(plan['music'].get('gain',1));fade=min(1440,len(mix)//2);mix[:fade]*=np.linspace(0,1,fade)[:,None];tail=min(14400,len(mix)//2);mix[-tail:]*=np.linspace(1,0,tail)[:,None]
 for e in plan.get('sfx',[]):
  name=e['asset'];asset=(SKILL/'assets/audio'/name).resolve()
  if not asset.is_relative_to(SKILL/'assets/audio') or not asset.exists():raise ValueError('SFX không thuộc assets/audio.')
  sound=decode(ff,asset);peak=np.max(np.abs(sound),axis=1);active=np.flatnonzero(peak>max(float(peak.max())*.02,.0001))
  if not len(active):continue
  sound=sound[max(0,int(active[0])-144):min(len(sound),int(active[-1])+2400)];sound*=float(e.get('peak',.075))/max(float(np.max(np.abs(sound))),.0001)
  f=min(144,len(sound)//2);sound[:f]*=np.linspace(0,1,f)[:,None];sound[-f:]*=np.linspace(1,0,f)[:,None];at=round(float(e['time'])*48000)
  if at<0 or at>=count:raise ValueError('SFX nằm ngoài timeline.')
  n=min(len(sound),count-at);mix[at:at+n]+=sound[:n]
 maximum=float(np.max(np.abs(mix)))
 if maximum>.98:mix*=.98/maximum
 with wave.open(str(work/'mix.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000);w.writeframes((mix*32767).astype('<i2').tobytes())
 m=subprocess.run([ff,'-hide_banner','-i',str(work/'mix.wav'),'-af','loudnorm=I=-14:TP=-1:LRA=9:print_format=json','-f','null','-'],capture_output=True,check=True).stderr.decode(errors='replace');measure=json.loads(m[m.rfind('{'):m.rfind('}')+1])
 norm='loudnorm=I=-14:TP=-1:LRA=9:measured_I={input_i}:measured_TP={input_tp}:measured_LRA={input_lra}:measured_thresh={input_thresh}:offset={target_offset}:linear=true'.format(**measure)
 run(ff,['-i',work/'base.mp4','-i',work/'type.mov','-i',work/'mix.wav','-filter_complex',f'[0:v]tpad=stop_mode=clone:stop_duration=1[b];[b][1:v]overlay=0:0:shortest=1[v];[2:a]{norm}[a]','-map','[v]','-map','[a]','-t',duration,'-r','30','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-ar','48000','-c:a','aac','-b:a','192k','-movflags','+faststart',output])
 run(ff,['-i',output,'-f','null','-'])
 meta=probe(fp,output);times=sorted(set([.1,max(0,duration-.15)]+[max(0,min(duration-.05,x+delta)) for x in cuts[:-1]+[float(c['start']) for c in plan['cues']] for delta in [-.05,.25,.8]]))
 cols=5;thumb=(180,320);sheet=Image.new('RGB',(cols*180,math.ceil(len(times)/cols)*345),(15,15,20));draw=ImageDraw.Draw(sheet)
 for i,t in enumerate(times):
  target=work/f'verify/frame_{i:03}.jpg';run(ff,['-ss',t,'-i',output,'-frames:v','1','-vf','scale=180:320',target]);x=i%cols*180;y=i//cols*345;sheet.paste(Image.open(target),(x,y));draw.text((x+8,y+324),f'{t:.2f}s',fill='white')
 sheet.save(work/'verify/contact_sheet.jpg')
 loud=subprocess.run([ff,'-hide_banner','-i',str(output),'-af','ebur128=peak=true','-f','null','-'],capture_output=True,check=True).stderr.decode(errors='replace');(work/'verify/loudness.txt').write_text(loud[loud.rfind('Summary:'):],encoding='utf-8')
 report={'output':str(output),'metadata':meta,'loudnorm_pass1':measure,'full_decode':'passed','contact_sheet':str(work/'verify/contact_sheet.jpg'),'audio_listened':False,'note':'Cần xem ảnh kiểm tra để xác nhận chữ tránh mặt; helper không tự nhận diện mặt.'};(work/'render_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'output':str(output),'report':str(work/'render_report.json')},ensure_ascii=True))
if __name__=='__main__':main()
