# Tài nguyên đi kèm

- Be Vietnam Pro Black/SemiBold: SIL Open Font License, xem fonts/OFL.txt. Nguồn: https://github.com/google/fonts/tree/main/ofl/bevietnampro .
- Kenney Interface Sounds: CC0, xem audio/Kenney-License.txt. Nguồn https://kenney.nl/assets/interface-sounds ; bản đóng gói lấy qua https://github.com/kapishdima/soundcn/tree/main/assets/kenney_interface-sounds .
- Cách dựng được tổng quát hóa từ bản video quảng cáo tranh V5 đã chốt trong cuộc hội thoại này, kết hợp skill edit-video-chuyen-gia.

Gói không chứa footage khách hàng, nhạc TikTok, cookie, khóa API hay tệp .env. Video và nhạc mới do người dùng cung cấp mỗi lần sử dụng; lưu nguồn và quyền dùng tương ứng trong job.
